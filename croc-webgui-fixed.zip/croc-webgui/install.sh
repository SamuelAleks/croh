#!/bin/bash
set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║       Croc Web GUI Installer           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo

# Check for root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root (use sudo)${NC}"
   exit 1
fi

# Get the actual user (not root)
if [[ -n "$SUDO_USER" ]]; then
    SERVICE_USER="$SUDO_USER"
    SERVICE_USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    echo -e "${RED}Please run with sudo, not as root directly${NC}"
    exit 1
fi

INSTALL_DIR="/opt/croc-webgui"
DATA_DIR="/var/lib/croc-webgui"

# Detect package manager
detect_package_manager() {
    if command -v pacman &> /dev/null; then
        echo "pacman"
    elif command -v apt-get &> /dev/null; then
        echo "apt"
    elif command -v dnf &> /dev/null; then
        echo "dnf"
    elif command -v yum &> /dev/null; then
        echo "yum"
    elif command -v brew &> /dev/null; then
        echo "brew"
    else
        echo "unknown"
    fi
}

PKG_MANAGER=$(detect_package_manager)
echo -e "${GREEN}Detected package manager:${NC} $PKG_MANAGER"

# Install system dependencies
# NOTE: Downloads use HTTPS but no checksum verification. This is intentional for simplicity
# and matches standard install patterns for these tools. For high-security environments,
# consider pre-installing croc and uv via your package manager or verifying checksums manually.
echo -e "${GREEN}[1/6]${NC} Installing system dependencies..."
case $PKG_MANAGER in
    pacman)
        pacman -S --needed --noconfirm croc python
        ;;
    apt)
        apt-get update
        apt-get install -y python3 python3-venv curl
        # croc needs to be installed separately on Debian/Ubuntu
        if ! command -v croc &> /dev/null; then
            echo "Installing croc..."
            curl -sL https://github.com/schollz/croc/releases/latest/download/croc_linux-64bit.tar.gz | tar xz -C /usr/local/bin
        fi
        ;;
    dnf|yum)
        $PKG_MANAGER install -y python3 python3-pip curl
        if ! command -v croc &> /dev/null; then
            echo "Installing croc..."
            curl -sL https://github.com/schollz/croc/releases/latest/download/croc_linux-64bit.tar.gz | tar xz -C /usr/local/bin
        fi
        ;;
    brew)
        sudo -u "$SERVICE_USER" brew install croc python
        ;;
    *)
        echo -e "${YELLOW}Warning: Unknown package manager. Please install croc and python manually.${NC}"
        ;;
esac

# Install uv if not present (install to /usr/local/bin for system-wide access)
echo -e "${GREEN}[2/6]${NC} Setting up uv package manager..."
if ! command -v uv &> /dev/null; then
    echo "Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | env CARGO_HOME=/usr/local UV_INSTALL_DIR=/usr/local/bin sh
fi

# Verify uv is available
if ! command -v uv &> /dev/null; then
    # Try common locations
    for uv_path in /usr/local/bin/uv "$SERVICE_USER_HOME/.local/bin/uv" "$SERVICE_USER_HOME/.cargo/bin/uv"; do
        if [[ -x "$uv_path" ]]; then
            UV_BIN="$uv_path"
            break
        fi
    done
    
    if [[ -z "$UV_BIN" ]]; then
        echo -e "${RED}Failed to install uv. Please install it manually:${NC}"
        echo "  curl -LsSf https://astral.sh/uv/install.sh | sh"
        exit 1
    fi
else
    UV_BIN="uv"
fi

echo -e "${GREEN}[3/6]${NC} Setting up application directory..."
mkdir -p "$INSTALL_DIR/static"
cp app.py "$INSTALL_DIR/"
cp static/index.html "$INSTALL_DIR/static/"
cp requirements.txt "$INSTALL_DIR/"

echo -e "${GREEN}[4/6]${NC} Creating Python virtual environment..."
$UV_BIN venv "$INSTALL_DIR/venv"
$UV_BIN pip install --python "$INSTALL_DIR/venv/bin/python" -r "$INSTALL_DIR/requirements.txt"

echo -e "${GREEN}[5/6]${NC} Setting up systemd service..."
cp croc-webgui@.service /etc/systemd/system/

# Create data directory for file transfers (replaces /tmp usage)
mkdir -p "$DATA_DIR"
chown "$SERVICE_USER":"$SERVICE_USER" "$DATA_DIR"
chmod 700 "$DATA_DIR"

# Set ownership of install directory
chown -R "$SERVICE_USER":"$SERVICE_USER" "$INSTALL_DIR"

systemctl daemon-reload

echo -e "${GREEN}[6/6]${NC} Starting service..."
systemctl enable "croc-webgui@${SERVICE_USER}"
systemctl start "croc-webgui@${SERVICE_USER}"

# Wait a moment and check status
sleep 2
if systemctl is-active --quiet "croc-webgui@${SERVICE_USER}"; then
    echo
    echo -e "${GREEN}✓ Installation complete!${NC}"
    echo
    echo "The Croc Web GUI is now running at: http://localhost:8317"
else
    echo
    echo -e "${YELLOW}⚠ Service may not have started correctly. Check logs:${NC}"
    echo "  journalctl -u croc-webgui@${SERVICE_USER} -n 20"
fi

echo
echo "Useful commands:"
echo "  sudo systemctl status croc-webgui@${SERVICE_USER}  - Check status"
echo "  sudo systemctl restart croc-webgui@${SERVICE_USER} - Restart service"
echo "  sudo systemctl stop croc-webgui@${SERVICE_USER}    - Stop service"
echo "  journalctl -u croc-webgui@${SERVICE_USER} -f       - View logs"
echo
echo "Data directory: $DATA_DIR"
echo "Received files can be saved to:"
echo "  - ~/Downloads, ~/Documents, etc. (user home directories)"
echo "  - $DATA_DIR (app default)"
echo "  - Any other writable directory"
