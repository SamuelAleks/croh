# Croc Web GUI

A modern web interface for [croc](https://github.com/schollz/croc) - the simplest and fastest way to transfer files between computers.

![Screenshot](https://img.shields.io/badge/Status-Ready-brightgreen)

## Features

- **Multi-file drag-and-drop** - Drop multiple files at once
- **Real-time transfer speed monitoring** - See transfer progress and speed via WebSocket
- **Auto-generated transfer codes** - One-click copy to clipboard
- **Receive files via code** - Just paste the code and receive
- **Download received files** - Click to download files after receiving
- **Configurable file size limits** - Set your own limits or disable them entirely
- **Croc options** - Custom codes, encryption curves, hash algorithms, throttling, and more
- **Dark/Light theme** - Easy on the eyes
- **Systemd integration** - Runs as a service on boot (Linux)
- **Windows service support** - Optional NSSM-based service installation
- **Cross-platform** - Works on Linux, macOS, and Windows

## Quick Install

### Linux / macOS

```bash
# Clone/download the files to a directory
cd croc-webgui

# Run the installer (works on Arch, Debian/Ubuntu, Fedora, macOS)
sudo ./install.sh
```

The installer will:
1. Detect your package manager and install `croc` + Python
2. Install `uv` for fast Python dependency management
3. Create a virtual environment and install dependencies
4. Set up the systemd service
5. Start the service automatically

### Windows

**Option A: Double-click the batch file (easiest)**
```
Double-click install.bat
```

**Option B: Run from PowerShell**
```powershell
# Navigate to the croc-webgui directory
cd croc-webgui

# Run the installer (if you get an execution policy error, use the command below)
.\install.ps1

# If blocked by execution policy, use this instead:
powershell -ExecutionPolicy Bypass -File .\install.ps1

# With options:
powershell -ExecutionPolicy Bypass -File .\install.ps1 -Port 9000      # Different port
powershell -ExecutionPolicy Bypass -File .\install.ps1 -NoService      # Run manually
```

The Windows installer will:
1. Check for Python 3.8+ (must be pre-installed)
2. Download and install `croc` if not present
3. Create a virtual environment and install dependencies
4. Create start scripts (`start.bat` and `start.ps1`)
5. Optionally install as a Windows service (requires [NSSM](https://nssm.cc/) and admin privileges)

**Prerequisites for Windows:**
- Python 3.8+ from [python.org](https://www.python.org/downloads/) (check "Add Python to PATH")
- (Optional) [NSSM](https://nssm.cc/) for service installation: `winget install nssm`

## Manual Installation

### Linux / macOS

```bash
# Install croc (choose your platform)
# Arch: sudo pacman -S croc
# Debian/Ubuntu: sudo apt install croc  (or download from GitHub)
# macOS: brew install croc

# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create venv and install dependencies
cd croc-webgui
uv venv
uv pip install -r requirements.txt

# Run directly
source .venv/bin/activate
uvicorn app:app --host 0.0.0.0 --port 8317
```

### Windows

```powershell
# Install croc (if not already installed)
# Option 1: Download from https://github.com/schollz/croc/releases
# Option 2: winget install schollz.croc

# Create venv and install dependencies
cd croc-webgui
python -m venv venv
.\venv\Scripts\pip install -r requirements.txt

# Run directly
.\venv\Scripts\uvicorn app:app --host 0.0.0.0 --port 8317
```

## Usage

1. Open `http://localhost:8317` in your browser

2. **To send files:**
   - Drag and drop files onto the drop zone (or click to browse)
   - Click "Start Transfer"
   - Share the generated code with the recipient

3. **To receive files:**
   - Switch to the "Receive Files" tab
   - Enter the transfer code
   - Click "Receive Files"
   - Once complete, click the file links to download

## Where Are Received Files Stored?

Received files are temporarily stored in platform-specific locations:

| Platform | Location |
|----------|----------|
| Linux | `/var/lib/croc-webgui/receive_<transfer_id>/` |
| macOS | `/var/lib/croc-webgui/receive_<transfer_id>/` or temp directory |
| Windows | `%LOCALAPPDATA%\croc-webgui\receive_<transfer_id>\` |

After receiving, you can download them through the web interface. Files are automatically cleaned up after 1 hour.

## Configuration

### GUI Settings

Click the ⚙️ button in the header to access settings. All settings are stored locally in your browser.

**File Limits:**
- Enable/disable file size limits
- Set max file size (MB/GB/TB)
- Set max total transfer size

**Croc Options:**
- **Custom code/passphrase** - Use your own phrase instead of auto-generated codes
- **Encryption curve** - Choose between P-256, P-384, P-521, or SIEC (default)
- **Hash algorithm** - xxHash (fastest), imohash, or MD5
- **Throttle speed** - Limit transfer speed (KB/s, MB/s, GB/s)
- **Custom relay** - Use your own relay server
- **Disable local transfer** - Force transfers through relay

**Appearance:**
- Dark/Light theme
- Google Fonts or system fonts

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `CROC_WEBGUI_PORT` | `8317` | Port to listen on |
| `CROC_WEBGUI_CORS_ORIGINS` | (empty) | CORS allowed origins. Empty = same-origin only. `*` = all origins. Comma-separated list for specific origins. |

### Change the port

Create a systemd override file:
```bash
sudo mkdir -p /etc/systemd/system/croc-webgui@$USER.service.d
sudo tee /etc/systemd/system/croc-webgui@$USER.service.d/override.conf << EOF
[Service]
Environment=CROC_WEBGUI_PORT=9000
EOF
sudo systemctl daemon-reload
sudo systemctl restart croc-webgui@$USER
```

### Configure CORS (for embedding in other apps)

```bash
sudo mkdir -p /etc/systemd/system/croc-webgui@$USER.service.d
sudo tee /etc/systemd/system/croc-webgui@$USER.service.d/override.conf << EOF
[Service]
Environment=CROC_WEBGUI_CORS_ORIGINS=https://myapp.example.com,https://other.example.com
EOF
sudo systemctl daemon-reload
sudo systemctl restart croc-webgui@$USER
```

### Firewall

If you want to access from other machines:

**Linux:**
```bash
# ufw (Ubuntu/Debian)
sudo ufw allow 8317/tcp

# firewalld (Fedora/RHEL)
sudo firewall-cmd --add-port=8317/tcp --permanent
sudo firewall-cmd --reload

# iptables
sudo iptables -A INPUT -p tcp --dport 8317 -j ACCEPT
```

**Windows (PowerShell as Admin):**
```powershell
New-NetFirewallRule -DisplayName "Croc Web GUI" -Direction Inbound -Port 8317 -Protocol TCP -Action Allow
```

## Service Management

### Linux (systemd)

```bash
# Check status
sudo systemctl status croc-webgui@$USER

# View logs
journalctl -u croc-webgui@$USER -f

# Restart
sudo systemctl restart croc-webgui@$USER

# Stop
sudo systemctl stop croc-webgui@$USER

# Disable (don't start on boot)
sudo systemctl disable croc-webgui@$USER
```

### Windows (NSSM)

```powershell
# Check status
nssm status croc-webgui

# Start
nssm start croc-webgui

# Stop
nssm stop croc-webgui

# Restart
nssm restart croc-webgui

# Remove service
nssm remove croc-webgui confirm

# Edit service configuration
nssm edit croc-webgui
```

## Uninstall

### Linux / macOS

```bash
# Run the uninstaller
sudo ./uninstall.sh

# Options:
sudo ./uninstall.sh --keep-data      # Keep received files and transfer data
sudo ./uninstall.sh --remove-croc    # Also remove croc binary (if installed by this tool)
sudo ./uninstall.sh --help           # Show all options
```

**Manual uninstall:**
```bash
# Stop and disable the service
sudo systemctl stop croc-webgui@$USER
sudo systemctl disable croc-webgui@$USER

# Remove systemd files
sudo rm /etc/systemd/system/croc-webgui@.service
sudo rm -rf /etc/systemd/system/croc-webgui@*.service.d
sudo systemctl daemon-reload

# Remove application files
sudo rm -rf /opt/croc-webgui

# Remove data directory (contains temporary transfer files)
sudo rm -rf /var/lib/croc-webgui
```

### Windows

```powershell
# Option A: Double-click uninstall.bat

# Option B: Run from PowerShell (as Administrator for service removal)
.\uninstall.ps1

# If blocked by execution policy:
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1

# Options:
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 -KeepData     # Keep received files
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 -RemoveCroc   # Also remove croc
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 -Force        # Skip confirmations
```

**Manual uninstall:**
```powershell
# If installed as a service (requires admin PowerShell)
nssm stop croc-webgui
nssm remove croc-webgui confirm

# Remove application files
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\croc-webgui"
```

## File Structure

```
croc-webgui/
├── app.py                # FastAPI backend
├── static/
│   └── index.html        # Web frontend
├── requirements.txt      # Python dependencies
├── install.sh            # Linux/macOS installation script
├── install.ps1           # Windows installation script (PowerShell)
├── install.bat           # Windows installer wrapper (double-click to run)
├── uninstall.sh          # Linux/macOS uninstallation script
├── uninstall.ps1         # Windows uninstallation script (PowerShell)
├── uninstall.bat         # Windows uninstaller wrapper (double-click to run)
├── croc-webgui@.service  # Systemd service file (Linux)
└── README.md
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Web interface |
| `/api/send` | POST | Upload files and start transfer |
| `/api/receive?code=xxx` | POST | Start receiving with code |
| `/api/transfer/{id}` | GET | Get transfer status |
| `/api/transfer/{id}` | DELETE | Cancel transfer |
| `/api/transfer/{id}/files` | GET | List received files |
| `/api/transfer/{id}/download/{filename}` | GET | Download a received file |
| `/ws/{id}` | WebSocket | Real-time progress updates |

## Troubleshooting

**"croc: command not found"**
```bash
# Arch
sudo pacman -S croc

# Debian/Ubuntu - download latest release
curl -sL https://github.com/schollz/croc/releases/latest/download/croc_linux-64bit.tar.gz | sudo tar xz -C /usr/local/bin

# macOS
brew install croc

# Windows (PowerShell)
winget install schollz.croc
# Or download from https://github.com/schollz/croc/releases
```

**Permission denied on data directory (Linux)**
```bash
sudo mkdir -p /var/lib/croc-webgui
sudo chown $USER:$USER /var/lib/croc-webgui
chmod 700 /var/lib/croc-webgui
```

**Service won't start (Linux)**
```bash
# Check logs for errors
journalctl -u croc-webgui@$USER -n 50

# Verify croc is installed
which croc

# Test manually
cd /opt/croc-webgui
./venv/bin/uvicorn app:app --host 0.0.0.0 --port 8317
```

**Service won't start (Windows)**
```powershell
# Check if NSSM service is installed
nssm status croc-webgui

# Check Windows Event Viewer for errors
eventvwr.msc

# Test manually
cd $env:LOCALAPPDATA\croc-webgui
.\venv\Scripts\uvicorn app:app --host 0.0.0.0 --port 8317
```

**Python not found (Windows)**
- Ensure Python 3.8+ is installed from [python.org](https://www.python.org/downloads/)
- Make sure "Add Python to PATH" was checked during installation
- Try running `py --version` instead of `python --version`

**PowerShell execution policy error (Windows)**
```
File cannot be loaded... is not digitally signed
```
Use the batch file wrapper instead (double-click `install.bat`), or run:
```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```
Or permanently allow local scripts for your user:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**WebSocket connection fails**
- If behind a reverse proxy, ensure it's configured to proxy WebSocket connections
- Check browser console for specific error messages

## Security

- File uploads are sanitized to prevent path traversal attacks
- Duplicate filenames are handled with unique suffixes
- File size limits configurable via settings (no server-side limit by default)
- Croc receive codes are validated before use
- XSS protection via HTML escaping
- Systemd service runs with hardened security settings
- Transfers auto-cleanup after 1 hour
- CORS disabled by default (same-origin only), configurable via environment variable
- Thread-safe transfer management with asyncio locks
- Content Security Policy headers enabled
- Graceful shutdown handling for active transfers

For production use, consider:
- Running behind a reverse proxy (nginx/caddy) with HTTPS
- Adding authentication (basic auth, OAuth, etc.)
- Restricting network access via firewall
- Configuring CORS to specific origins

## Reverse Proxy Example (Nginx)

```nginx
server {
    listen 443 ssl http2;
    server_name croc.example.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://127.0.0.1:8317;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # For large file uploads
        client_max_body_size 10G;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}
```

## License

MIT
