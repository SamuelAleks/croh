<#
.SYNOPSIS
    Croc Web GUI Uninstaller for Windows

.DESCRIPTION
    Removes Croc Web GUI installation including service, application files, and optionally data.
    Requires administrator privileges if installed as a service.

.PARAMETER KeepData
    Keep the data directory (received files, transfer history)

.PARAMETER RemoveCroc
    Also remove croc binary if it was installed to %LOCALAPPDATA%\croc

.PARAMETER Force
    Skip confirmation prompts

.EXAMPLE
    .\uninstall.ps1
    
.EXAMPLE
    .\uninstall.ps1 -KeepData -Force
#>

param(
    [switch]$KeepData,
    [switch]$RemoveCroc,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# Colors and formatting
function Write-Header {
    Write-Host ""
    Write-Host "+------------------------------------------+" -ForegroundColor Blue
    Write-Host "|       Croc Web GUI Uninstaller           |" -ForegroundColor Blue
    Write-Host "|            (Windows)                     |" -ForegroundColor Blue
    Write-Host "+------------------------------------------+" -ForegroundColor Blue
    Write-Host ""
}

function Write-Step {
    param([string]$Step, [string]$Message)
    Write-Host "[$Step]" -ForegroundColor Green -NoNewline
    Write-Host " $Message"
}

function Write-WarningCustom {
    param([string]$Message)
    Write-Host "[!] $Message" -ForegroundColor Yellow
}

function Write-ErrorCustom {
    param([string]$Message)
    Write-Host "[X] $Message" -ForegroundColor Red
}

function Write-Success {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

# Check for admin privileges
function Test-Admin {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Write-Header

$InstallDir = "$env:LOCALAPPDATA\croc-webgui"
$CrocDir = "$env:LOCALAPPDATA\croc"
$ServiceName = "croc-webgui"

# Check what exists
$hasInstallDir = Test-Path $InstallDir
$hasService = $false
$hasCroc = Test-Path "$CrocDir\croc.exe"

# Check for NSSM service
$nssm = Get-Command nssm -ErrorAction SilentlyContinue
if ($nssm) {
    $serviceStatus = & nssm status $ServiceName 2>&1
    if ($serviceStatus -notmatch "Can't open service") {
        $hasService = $true
    }
}

# Also check native Windows service
$nativeService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($nativeService) {
    $hasService = $true
}

if (-not $hasInstallDir -and -not $hasService) {
    Write-WarningCustom "Croc Web GUI does not appear to be installed."
    Write-Host "  Install directory not found: $InstallDir"
    Write-Host ""
    exit 0
}

# Show what will be removed
Write-Host "This will remove:" -ForegroundColor Yellow
if ($hasService) {
    Write-Host "  - Windows service: $ServiceName"
}
if ($hasInstallDir) {
    Write-Host "  - Application directory: $InstallDir"
}
if (-not $KeepData -and $hasInstallDir) {
    Write-Host "  - Data files (uploads, received files)"
} elseif ($KeepData) {
    Write-Host "  - Data files: " -NoNewline
    Write-Host "(keeping)" -ForegroundColor Green
}
if ($RemoveCroc -and $hasCroc) {
    Write-Host "  - Croc binary: $CrocDir"
}
Write-Host ""

# Confirmation
if (-not $Force) {
    $response = Read-Host "Are you sure you want to continue? (y/N)"
    if ($response -ne 'y' -and $response -ne 'Y') {
        Write-Host "Uninstall cancelled."
        exit 0
    }
    Write-Host ""
}

# Step 1: Stop and remove service
Write-Step "1/4" "Stopping and removing service..."

if ($hasService) {
    if (-not (Test-Admin)) {
        Write-WarningCustom "Administrator privileges required to remove service."
        Write-Host "  Please run this script as Administrator."
        Write-Host "  Skipping service removal..."
    } else {
        # Try NSSM first
        if ($nssm) {
            try {
                $ErrorActionPreference = "SilentlyContinue"
                $null = & nssm stop $ServiceName 2>&1
                Start-Sleep -Seconds 2
                $null = & nssm remove $ServiceName confirm 2>&1
                $ErrorActionPreference = "Stop"
                Write-Host "  Removed NSSM service"
            } catch {
                $ErrorActionPreference = "Stop"
                Write-Host "  NSSM service removal failed (may not exist)"
            }
        }
        
        # Try native service
        $nativeService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($nativeService) {
            try {
                $ErrorActionPreference = "SilentlyContinue"
                Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
                $null = sc.exe delete $ServiceName 2>&1
                $ErrorActionPreference = "Stop"
                Write-Host "  Removed native Windows service"
            } catch {
                $ErrorActionPreference = "Stop"
                Write-Host "  Native service removal failed"
            }
        }
    }
} else {
    Write-Host "  No service found"
}

# Step 2: Kill any running processes
Write-Step "2/4" "Stopping running processes..."

$uvicornProcesses = Get-Process -Name "uvicorn" -ErrorAction SilentlyContinue | Where-Object {
    $_.Path -like "*croc-webgui*"
}

if ($uvicornProcesses) {
    $uvicornProcesses | Stop-Process -Force
    Write-Host "  Stopped running uvicorn processes"
} else {
    Write-Host "  No running processes found"
}

# Step 3: Remove application directory
Write-Step "3/4" "Removing application files..."

if ($hasInstallDir) {
    if ($KeepData) {
        # Remove everything except data that might be in the install dir
        # The actual data is stored in the same directory for Windows
        $itemsToRemove = @(
            "$InstallDir\app.py",
            "$InstallDir\requirements.txt",
            "$InstallDir\start.bat",
            "$InstallDir\start.ps1",
            "$InstallDir\static",
            "$InstallDir\venv"
        )
        
        foreach ($item in $itemsToRemove) {
            if (Test-Path $item) {
                Remove-Item -Path $item -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
        Write-Host "  Removed application files (keeping data)"
        
        # Check if directory is now empty (except for transfer data)
        $remaining = Get-ChildItem -Path $InstallDir -ErrorAction SilentlyContinue
        if ($remaining.Count -eq 0) {
            Remove-Item -Path $InstallDir -Force
            Write-Host "  Removed empty install directory"
        } else {
            Write-Host "  Data preserved in: $InstallDir"
        }
    } else {
        # Check for files before removing
        $fileCount = (Get-ChildItem -Path $InstallDir -Recurse -File -ErrorAction SilentlyContinue).Count
        
        if ($fileCount -gt 10 -and -not $Force) {
            Write-WarningCustom "Directory contains $fileCount files"
            $response = Read-Host "  Delete anyway? (y/N)"
            if ($response -ne 'y' -and $response -ne 'Y') {
                Write-Host "  Keeping $InstallDir"
            } else {
                Remove-Item -Path $InstallDir -Recurse -Force
                Write-Host "  Removed $InstallDir"
            }
        } else {
            Remove-Item -Path $InstallDir -Recurse -Force
            Write-Host "  Removed $InstallDir"
        }
    }
} else {
    Write-Host "  Install directory not found"
}

# Step 4: Optionally remove croc
Write-Step "4/4" "Handling croc binary..."

if ($RemoveCroc) {
    if ($hasCroc) {
        # Remove from PATH
        $userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
        if ($userPath -like "*$CrocDir*") {
            $newPath = ($userPath -split ';' | Where-Object { $_ -ne $CrocDir }) -join ';'
            [Environment]::SetEnvironmentVariable("PATH", $newPath, "User")
            Write-Host "  Removed croc from PATH"
        }
        
        # Remove directory
        Remove-Item -Path $CrocDir -Recurse -Force
        Write-Host "  Removed $CrocDir"
    } else {
        Write-Host "  Croc not found in $CrocDir (installed elsewhere?)"
    }
} else {
    if ($hasCroc) {
        Write-Host "  Keeping croc binary (use -RemoveCroc to remove)"
    } else {
        Write-Host "  Croc not installed by this tool"
    }
}

Write-Host ""
Write-Success "Uninstall complete!"
Write-Host ""

# Cleanup reminders
if ($KeepData -and (Test-Path $InstallDir)) {
    Write-Host "Note: Data preserved in $InstallDir"
    Write-Host "To remove manually: Remove-Item -Recurse -Force '$InstallDir'"
    Write-Host ""
}
