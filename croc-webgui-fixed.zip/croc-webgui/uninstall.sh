#!/bin/bash
set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║       Croc Web GUI Uninstaller         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}"
echo

# Check for root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root (use sudo)${NC}"
   exit 1
fi

# Get the actual user (not root)
if [[ -n "$SUDO_USER" ]]; then
    SERVICE_USER="$SUDO_USER"
else
    echo -e "${RED}Please run with sudo, not as root directly${NC}"
    exit 1
fi

INSTALL_DIR="/opt/croc-webgui"
DATA_DIR="/var/lib/croc-webgui"
SERVICE_NAME="croc-webgui@${SERVICE_USER}"

# Flags
KEEP_DATA=false
REMOVE_CROC=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --keep-data)
            KEEP_DATA=true
            shift
            ;;
        --remove-croc)
            REMOVE_CROC=true
            shift
            ;;
        -h|--help)
            echo "Usage: sudo ./uninstall.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --keep-data     Keep the data directory (received files, etc.)"
            echo "  --remove-croc   Also remove croc binary (if installed by this tool)"
            echo "  -h, --help      Show this help message"
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# Confirmation
echo -e "${YELLOW}This will remove:${NC}"
echo "  • Systemd service: $SERVICE_NAME"
echo "  • Application directory: $INSTALL_DIR"
if [[ "$KEEP_DATA" == false ]]; then
    echo "  • Data directory: $DATA_DIR"
else
    echo -e "  • Data directory: ${GREEN}(keeping)${NC}"
fi
if [[ "$REMOVE_CROC" == true ]]; then
    echo "  • Croc binary: /usr/local/bin/croc (if present)"
fi
echo

read -p "Are you sure you want to continue? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Uninstall cancelled."
    exit 0
fi

echo

# Step 1: Stop and disable service
echo -e "${GREEN}[1/4]${NC} Stopping and removing systemd service..."
if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    systemctl stop "$SERVICE_NAME"
    echo "  Stopped $SERVICE_NAME"
fi

if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
    systemctl disable "$SERVICE_NAME"
    echo "  Disabled $SERVICE_NAME"
fi

# Remove service file
if [[ -f /etc/systemd/system/croc-webgui@.service ]]; then
    rm -f /etc/systemd/system/croc-webgui@.service
    systemctl daemon-reload
    echo "  Removed service file"
else
    echo "  Service file not found (already removed?)"
fi

# Step 2: Remove application directory
echo -e "${GREEN}[2/4]${NC} Removing application directory..."
if [[ -d "$INSTALL_DIR" ]]; then
    rm -rf "$INSTALL_DIR"
    echo "  Removed $INSTALL_DIR"
else
    echo "  $INSTALL_DIR not found (already removed?)"
fi

# Step 3: Remove data directory (unless --keep-data)
echo -e "${GREEN}[3/4]${NC} Handling data directory..."
if [[ "$KEEP_DATA" == true ]]; then
    echo "  Keeping $DATA_DIR (--keep-data specified)"
elif [[ -d "$DATA_DIR" ]]; then
    # Check if there are any files
    file_count=$(find "$DATA_DIR" -type f 2>/dev/null | wc -l)
    if [[ $file_count -gt 0 ]]; then
        echo -e "  ${YELLOW}Warning: Data directory contains $file_count file(s)${NC}"
        read -p "  Delete anyway? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$DATA_DIR"
            echo "  Removed $DATA_DIR"
        else
            echo "  Keeping $DATA_DIR"
        fi
    else
        rm -rf "$DATA_DIR"
        echo "  Removed $DATA_DIR"
    fi
else
    echo "  $DATA_DIR not found (already removed?)"
fi

# Step 4: Optionally remove croc
echo -e "${GREEN}[4/4]${NC} Handling croc binary..."
if [[ "$REMOVE_CROC" == true ]]; then
    if [[ -f /usr/local/bin/croc ]]; then
        rm -f /usr/local/bin/croc
        echo "  Removed /usr/local/bin/croc"
    else
        echo "  /usr/local/bin/croc not found (installed via package manager?)"
    fi
else
    echo "  Keeping croc binary (use --remove-croc to remove)"
fi

echo
echo -e "${GREEN}✓ Uninstall complete!${NC}"
echo

if [[ "$KEEP_DATA" == true ]] && [[ -d "$DATA_DIR" ]]; then
    echo "Note: Data directory preserved at $DATA_DIR"
    echo "To remove it manually: sudo rm -rf $DATA_DIR"
    echo
fi
