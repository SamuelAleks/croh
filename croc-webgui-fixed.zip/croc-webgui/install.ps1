<#
.SYNOPSIS
    Croc Web GUI Installer for Windows

.DESCRIPTION
    Installs Croc Web GUI as a Windows service or for manual execution.
    Requires PowerShell 5.1+ and administrator privileges for service installation.

.PARAMETER NoService
    Install without registering as a Windows service (run manually)

.PARAMETER Port
    Port to run the web GUI on (default: 8317)

.EXAMPLE
    .\install.ps1
    
.EXAMPLE
    .\install.ps1 -NoService -Port 9000
#>

param(
    [switch]$NoService,
    [int]$Port = 8317
)

$ErrorActionPreference = "Stop"

# Colors and formatting
function Write-Header {
    Write-Host ""
    Write-Host "+------------------------------------------+" -ForegroundColor Blue
    Write-Host "|       Croc Web GUI Installer             |" -ForegroundColor Blue
    Write-Host "|            (Windows)                     |" -ForegroundColor Blue
    Write-Host "+------------------------------------------+" -ForegroundColor Blue
    Write-Host ""
}

function Write-Step {
    param([string]$Step, [string]$Message)
    Write-Host "[$Step]" -ForegroundColor Green -NoNewline
    Write-Host " $Message"
}

function Write-WarningCustom {
    param([string]$Message)
    Write-Host "[!] $Message" -ForegroundColor Yellow
}

function Write-ErrorCustom {
    param([string]$Message)
    Write-Host "[X] $Message" -ForegroundColor Red
}

function Write-Success {
    param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

# Check for admin privileges (only required for service installation)
function Test-Admin {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Find or install Python
function Get-Python {
    # Try common Python commands
    $pythonCommands = @("python", "python3", "py")
    
    foreach ($cmd in $pythonCommands) {
        try {
            $version = & $cmd --version 2>&1
            if ($version -match "Python 3\.([0-9]+)") {
                $minor = [int]$Matches[1]
                if ($minor -ge 8) {
                    return $cmd
                }
            }
        } catch {
            continue
        }
    }
    
    return $null
}

# Download file with progress
function Get-FileFromUrl {
    param([string]$Url, [string]$Output)
    
    $webClient = New-Object System.Net.WebClient
    $webClient.DownloadFile($Url, $Output)
}

# Main installation
Write-Header

$InstallDir = "$env:LOCALAPPDATA\croc-webgui"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Step 1: Check Python
Write-Step "1/5" "Checking Python installation..."
$Python = Get-Python

if (-not $Python) {
    Write-ErrorCustom "Python 3.8+ is required but not found."
    Write-Host ""
    Write-Host "Please install Python from https://www.python.org/downloads/"
    Write-Host "Make sure to check 'Add Python to PATH' during installation."
    exit 1
}

$pythonVersion = & $Python --version 2>&1
Write-Host "  Found: $pythonVersion"

# Step 2: Check/Install croc
Write-Step "2/5" "Checking croc installation..."

$crocPath = Get-Command croc -ErrorAction SilentlyContinue

if (-not $crocPath) {
    Write-Host "  croc not found, installing..."
    
    # Determine architecture
    $arch = if ([Environment]::Is64BitOperatingSystem) { "64bit" } else { "32bit" }
    $crocUrl = "https://github.com/schollz/croc/releases/latest/download/croc_windows-$arch.zip"
    $crocZip = "$env:TEMP\croc.zip"
    $crocExtract = "$env:TEMP\croc_extract"
    $crocInstallDir = "$env:LOCALAPPDATA\croc"
    
    try {
        Write-Host "  Downloading croc..."
        Get-FileFromUrl -Url $crocUrl -Output $crocZip
        
        Write-Host "  Extracting..."
        if (Test-Path $crocExtract) { Remove-Item -Recurse -Force $crocExtract }
        Expand-Archive -Path $crocZip -DestinationPath $crocExtract -Force
        
        # Create install directory and copy croc
        if (-not (Test-Path $crocInstallDir)) {
            New-Item -ItemType Directory -Path $crocInstallDir -Force | Out-Null
        }
        Copy-Item "$crocExtract\croc.exe" "$crocInstallDir\croc.exe" -Force
        
        # Add to user PATH if not already there
        $userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
        if ($userPath -notlike "*$crocInstallDir*") {
            [Environment]::SetEnvironmentVariable("PATH", "$userPath;$crocInstallDir", "User")
            $env:PATH = "$env:PATH;$crocInstallDir"
            Write-Host "  Added croc to PATH"
        }
        
        # Cleanup
        Remove-Item -Force $crocZip -ErrorAction SilentlyContinue
        Remove-Item -Recurse -Force $crocExtract -ErrorAction SilentlyContinue
        
        Write-Success "croc installed to $crocInstallDir"
    } catch {
        Write-ErrorCustom "Failed to install croc: $_"
        Write-Host "Please install croc manually from https://github.com/schollz/croc/releases"
        exit 1
    }
} else {
    $crocVersion = & croc --version 2>&1
    Write-Host "  Found: $crocVersion"
}

# Step 3: Create installation directory
Write-Step "3/5" "Setting up application directory..."

if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

# Copy application files
Copy-Item "$ScriptDir\app.py" "$InstallDir\" -Force
if (-not (Test-Path "$InstallDir\static")) {
    New-Item -ItemType Directory -Path "$InstallDir\static" -Force | Out-Null
}
Copy-Item "$ScriptDir\static\index.html" "$InstallDir\static\" -Force
Copy-Item "$ScriptDir\requirements.txt" "$InstallDir\" -Force

Write-Host "  Installed to: $InstallDir"

# Step 4: Create virtual environment and install dependencies
Write-Step "4/5" "Creating Python virtual environment..."

$venvPath = "$InstallDir\venv"
if (Test-Path $venvPath) {
    Write-Host "  Removing existing venv..."
    Remove-Item -Recurse -Force $venvPath
}

& $Python -m venv $venvPath
if ($LASTEXITCODE -ne 0) {
    Write-ErrorCustom "Failed to create virtual environment"
    exit 1
}

Write-Host "  Installing dependencies..."
& "$venvPath\Scripts\pip.exe" install --quiet -r "$InstallDir\requirements.txt"
if ($LASTEXITCODE -ne 0) {
    Write-ErrorCustom "Failed to install dependencies"
    exit 1
}

# Step 5: Create start script and optionally install as service
Write-Step "5/5" "Creating start script..."

$startScript = @"
@echo off
setlocal
set CROC_WEBGUI_PORT=$Port
cd /d "$InstallDir"
echo Starting Croc Web GUI on port %CROC_WEBGUI_PORT%...
echo Press Ctrl+C to stop the server.
echo.
"$venvPath\Scripts\uvicorn.exe" app:app --host 0.0.0.0 --port %CROC_WEBGUI_PORT%
echo.
echo Server stopped.
pause
"@

$startScriptPath = "$InstallDir\start.bat"
$startScript | Out-File -FilePath $startScriptPath -Encoding ASCII

# Create PowerShell start script too
$startPsScript = @"
`$env:CROC_WEBGUI_PORT = "$Port"
Set-Location "$InstallDir"
Write-Host "Starting Croc Web GUI on port `$env:CROC_WEBGUI_PORT..." -ForegroundColor Green
Write-Host "Press Ctrl+C to stop the server."
Write-Host ""
try {
    & "$venvPath\Scripts\uvicorn.exe" app:app --host 0.0.0.0 --port `$env:CROC_WEBGUI_PORT
} finally {
    Write-Host ""
    Write-Host "Server stopped."
    Read-Host "Press Enter to exit"
}
"@

$startPsScriptPath = "$InstallDir\start.ps1"
$startPsScript | Out-File -FilePath $startPsScriptPath -Encoding UTF8

if (-not $NoService) {
    if (-not (Test-Admin)) {
        Write-WarningCustom "Administrator privileges required to install as a service."
        Write-Host "  Run this script as Administrator, or use -NoService flag."
        Write-Host ""
        Write-Host "To run manually instead:"
        Write-Host "  $startScriptPath"
        Write-Host ""
    } else {
        # Try to use NSSM if available, otherwise provide instructions
        $nssm = Get-Command nssm -ErrorAction SilentlyContinue
        
        if ($nssm) {
            Write-Host "  Installing Windows service using NSSM..."
            
            # Remove existing service if present (ignore errors if it doesn't exist)
            try {
                $ErrorActionPreference = "SilentlyContinue"
                $null = & nssm stop croc-webgui 2>&1
                $null = & nssm remove croc-webgui confirm 2>&1
                $ErrorActionPreference = "Stop"
            } catch {
                # Service doesn't exist yet, that's fine
            }
            
            # Find croc path to pass to service
            $crocExePath = (Get-Command croc -ErrorAction SilentlyContinue).Source
            if (-not $crocExePath) {
                # Fallback to where we installed it
                $crocExePath = "$env:LOCALAPPDATA\croc\croc.exe"
            }
            
            # Install new service
            & nssm install croc-webgui "$venvPath\Scripts\uvicorn.exe" "app:app --host 0.0.0.0 --port $Port"
            & nssm set croc-webgui AppDirectory "$InstallDir"
            & nssm set croc-webgui DisplayName "Croc Web GUI"
            & nssm set croc-webgui Description "Web interface for croc file transfers"
            & nssm set croc-webgui Start SERVICE_AUTO_START
            # Pass both PORT and the explicit path to croc executable
            & nssm set croc-webgui AppEnvironmentExtra "CROC_WEBGUI_PORT=$Port" "CROC_PATH=$crocExePath"
            & nssm start croc-webgui
            
            Write-Success "Service installed and started!"
        } else {
            Write-WarningCustom "NSSM not found. Service installation skipped."
            Write-Host ""
            Write-Host "  To install as a Windows service, install NSSM:"
            Write-Host "    winget install nssm"
            Write-Host "  Then run this installer again."
            Write-Host ""
            Write-Host "  Or run manually with:"
            Write-Host "    $startScriptPath"
        }
    }
} else {
    Write-Host "  Service installation skipped (-NoService flag)"
}

# Done!
Write-Host ""
Write-Success "Installation complete!"
Write-Host ""
Write-Host "The Croc Web GUI can be accessed at: " -NoNewline
Write-Host "http://localhost:$Port" -ForegroundColor Cyan
Write-Host ""
Write-Host "To start manually:"
Write-Host "  $startScriptPath"
Write-Host "  or"
Write-Host "  $startPsScriptPath"
Write-Host ""
Write-Host "Data directory: $env:LOCALAPPDATA\croc-webgui"
Write-Host ""

# Offer to start now if not running as service
if ($NoService -or -not (Test-Admin)) {
    $response = Read-Host "Start the server now? (y/N)"
    if ($response -eq 'y' -or $response -eq 'Y') {
        Write-Host ""
        Write-Host "Starting server... Press Ctrl+C to stop."
        Write-Host ""
        try {
            & "$venvPath\Scripts\uvicorn.exe" app:app --host 0.0.0.0 --port $Port
        } finally {
            Write-Host ""
            Write-Host "Server stopped."
            Read-Host "Press Enter to exit"
        }
    }
}
