#!/usr/bin/env python3
"""
Croc Web GUI - A web interface for the croc file transfer tool
"""

from __future__ import annotations

# Configure multipart parser limits BEFORE importing starlette
# This increases the maximum size for form data parsing
import os
os.environ.setdefault("STARLETTE_MAX_FORM_MEMORY_SIZE", str(1024 * 1024 * 1024))  # 1GB in-memory limit
os.environ.setdefault("PYTHON_MULTIPART_SPOOL_MAX_SIZE", str(10 * 1024 * 1024))  # 10MB before spooling to disk

import asyncio
import logging
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, Query, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from starlette.requests import ClientDisconnect

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# Base directory for resolving relative paths
BASE_DIR = Path(__file__).parent.resolve()

# Configuration from environment variables
PORT = int(os.environ.get("CROC_WEBGUI_PORT", "8317"))
CORS_ORIGINS = os.environ.get("CROC_WEBGUI_CORS_ORIGINS", "").strip()
TRANSFER_EXPIRY_SECONDS = 3600  # Clean up transfers after 1 hour
TRANSFER_TIMEOUT_SECONDS = 7200  # Force cleanup stuck transfers after 2 hours

# NOTE: File size limits are enforced client-side via settings. No server-side limit.
# NOTE: Rate limiting is intentionally omitted. This tool is designed for personal/LAN use
# where rate limiting adds complexity without meaningful benefit. For public deployments,
# consider adding rate limiting via a reverse proxy (e.g., nginx limit_req).

# More permissive pattern: number-word-word with optional additional segments
CROC_CODE_PATTERN = re.compile(r'^[a-zA-Z0-9]+(-[a-zA-Z0-9]+){2,}$')

# Valid croc option values
VALID_CURVES = {"p256", "p384", "p521", "siec"}
VALID_HASHES = {"xxhash", "imohash", "md5"}


def find_croc_executable() -> str:
    """Find the croc executable, checking common installation locations on Windows"""
    # First, check for explicit CROC_PATH environment variable (set by service installer)
    croc_env_path = os.environ.get("CROC_PATH")
    if croc_env_path and Path(croc_env_path).exists():
        logger.info(f"Using croc from CROC_PATH: {croc_env_path}")
        return croc_env_path
    
    # Next, try to find croc in PATH
    croc_path = shutil.which("croc")
    if croc_path:
        return croc_path
    
    # On Windows, check common installation locations
    if sys.platform == "win32":
        possible_paths = []
        
        # Check LOCALAPPDATA for current user
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        if local_app_data:
            possible_paths.append(Path(local_app_data) / "croc" / "croc.exe")
        
        # Check common user profile locations (for when running as service)
        # Services often run as SYSTEM, so we need to check actual user paths
        users_dir = Path("C:/Users")
        if users_dir.exists():
            for user_dir in users_dir.iterdir():
                if user_dir.is_dir() and user_dir.name not in ("Public", "Default", "Default User", "All Users"):
                    possible_paths.append(user_dir / "AppData" / "Local" / "croc" / "croc.exe")
                    # Also check scoop installations
                    possible_paths.append(user_dir / "scoop" / "shims" / "croc.exe")
        
        # Installed via scoop for current user
        user_profile = os.environ.get("USERPROFILE", "")
        if user_profile:
            possible_paths.append(Path(user_profile) / "scoop" / "shims" / "croc.exe")
        
        # Installed via chocolatey
        program_data = os.environ.get("ProgramData", "")
        if program_data:
            possible_paths.append(Path(program_data) / "chocolatey" / "bin" / "croc.exe")
        
        # Installed manually to Program Files
        program_files = os.environ.get("ProgramFiles", "")
        if program_files:
            possible_paths.append(Path(program_files) / "croc" / "croc.exe")
        
        program_files_x86 = os.environ.get("ProgramFiles(x86)", "")
        if program_files_x86:
            possible_paths.append(Path(program_files_x86) / "croc" / "croc.exe")
        
        for path in possible_paths:
            if path and path.exists():
                logger.info(f"Found croc at: {path}")
                return str(path)
    
    # Fallback to just "croc" and let it fail with a clear error
    return "croc"


# Cache the croc path at startup
CROC_EXECUTABLE = find_croc_executable()
logger.info(f"Using croc executable: {CROC_EXECUTABLE}")


class CrocOptions(BaseModel):
    """Options for croc transfers"""
    code: Optional[str] = None  # Custom code/passphrase
    curve: Optional[str] = None  # Encryption curve: p256, p384, p521, siec
    hash: Optional[str] = None  # Hash algorithm: xxhash, imohash, md5
    throttle: Optional[str] = None  # Throttle speed, e.g., "1M" for 1MB/s
    relay: Optional[str] = None  # Custom relay address
    no_local: bool = False  # Disable local network transfer
    
    def to_args(self) -> List[str]:
        """Convert options to croc command line arguments"""
        args = []
        if self.code:
            args.extend(["--pass", self.code])
        if self.curve and self.curve in VALID_CURVES:
            args.extend(["--curve", self.curve])
        if self.hash and self.hash in VALID_HASHES:
            args.extend(["--hash", self.hash])
        if self.throttle:
            # Validate throttle format (number followed by optional K/M/G)
            if re.match(r'^\d+(\.\d+)?[KMG]?$', self.throttle, re.IGNORECASE):
                args.extend(["--throttle", self.throttle])
        if self.relay:
            # Basic validation for relay address
            if re.match(r'^[a-zA-Z0-9\.\-]+:\d+$', self.relay):
                args.extend(["--relay", self.relay])
        if self.no_local:
            args.append("--no-local")
        return args

from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events"""
    # Startup
    cleanup_task = asyncio.create_task(periodic_cleanup())
    yield
    # Shutdown
    cleanup_task.cancel()
    await graceful_shutdown()


app = FastAPI(title="Croc Web GUI", lifespan=lifespan)

# Add CORS middleware - configure origins via environment variable
# Empty or unset = same-origin only (no CORS headers added for same-origin requests)
# "*" = allow all origins (development only!)
# "https://example.com,https://other.com" = specific origins
cors_origins_list: List[str] = []
if CORS_ORIGINS:
    if CORS_ORIGINS == "*":
        cors_origins_list = ["*"]
    else:
        cors_origins_list = [origin.strip() for origin in CORS_ORIGINS.split(",") if origin.strip()]

if cors_origins_list:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Use platform-appropriate persistent storage
# Linux: /var/lib for persistent storage (works with systemd hardening)
# Windows: LocalAppData for user-specific persistent storage
# Falls back to temp directory for development or permission issues
if sys.platform == "win32":
    _app_data = os.environ.get("LOCALAPPDATA", "")
    UPLOAD_DIR = Path(_app_data) / "croc-webgui" if _app_data else Path(tempfile.gettempdir()) / "croc-webgui"
else:
    UPLOAD_DIR = Path("/var/lib/croc-webgui")

if not UPLOAD_DIR.exists():
    try:
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        if sys.platform != "win32":
            UPLOAD_DIR.chmod(0o700)
    except PermissionError:
        UPLOAD_DIR = Path(tempfile.gettempdir()) / "croc-webgui"
        UPLOAD_DIR.mkdir(exist_ok=True)
        if sys.platform != "win32":
            UPLOAD_DIR.chmod(0o700)

# Store active transfers with lock for thread safety
transfers: Dict[str, "Transfer"] = {}
transfers_lock = asyncio.Lock()

# Shutdown flag for graceful termination
shutdown_event = asyncio.Event()


async def periodic_cleanup():
    """Run cleanup periodically to remove stale transfers"""
    while not shutdown_event.is_set():
        try:
            await asyncio.sleep(300)  # Every 5 minutes
            await cleanup_old_transfers()
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"Periodic cleanup error: {e}")


def secure_filename(filename: str) -> str:
    """Sanitize filename to prevent path traversal"""
    # Get just the filename, no directory components
    name = Path(filename).name
    # Remove any remaining dangerous characters
    name = re.sub(r'[^\w\s\-\.]', '_', name)
    # Strip whitespace and prevent empty or dot-only names
    name = name.strip()
    if not name or name.startswith('.'):
        name = f"file_{secrets.token_hex(4)}"
    return name


def get_unique_filepath(directory: Path, filename: str) -> Path:
    """Get a unique filepath, adding suffix if file already exists"""
    filepath = directory / filename
    if not filepath.exists():
        return filepath
    
    stem = filepath.stem
    suffix = filepath.suffix
    counter = 1
    while filepath.exists():
        filepath = directory / f"{stem}_{counter}{suffix}"
        counter += 1
    return filepath


@dataclass
class Transfer:
    id: str
    type: str  # "send" or "receive"
    code: Optional[str] = None
    files: List[str] = field(default_factory=list)
    status: str = "pending"
    progress: float = 0.0
    speed: str = ""
    error: Optional[str] = None
    process: Optional[asyncio.subprocess.Process] = None
    websocket: Optional[WebSocket] = None
    start_time: float = field(default_factory=time.time)
    total_size: int = 0
    transferred: int = 0
    options: Optional[CrocOptions] = None
    receive_dir: Optional[Path] = None  # Directory where received files are stored
    _pending_messages: List = field(default_factory=list)


async def cleanup_old_transfers():
    """Remove expired transfers and their files"""
    now = time.time()
    
    async with transfers_lock:
        expired = [
            tid for tid, t in transfers.items()
            if (now - t.start_time > TRANSFER_EXPIRY_SECONDS
                and t.status in ("completed", "failed", "cancelled"))
            or (now - t.start_time > TRANSFER_TIMEOUT_SECONDS)  # Force cleanup stuck transfers
        ]
        
        for tid in expired:
            transfer = transfers.pop(tid, None)
            if transfer:
                # Kill any stuck processes
                if transfer.process and transfer.process.returncode is None:
                    try:
                        transfer.process.terminate()
                        await asyncio.wait_for(transfer.process.wait(), timeout=5)
                    except asyncio.TimeoutError:
                        transfer.process.kill()
                    except Exception:
                        pass
                
                # Clean up files using shutil.rmtree for reliability
                transfer_dir = UPLOAD_DIR / tid
                if transfer_dir.exists():
                    try:
                        shutil.rmtree(transfer_dir, ignore_errors=True)
                    except Exception as e:
                        logger.warning(f"Failed to clean up {transfer_dir}: {e}")
                
                receive_dir = UPLOAD_DIR / f"receive_{tid}"
                if receive_dir.exists():
                    try:
                        shutil.rmtree(receive_dir, ignore_errors=True)
                    except Exception as e:
                        logger.warning(f"Failed to clean up {receive_dir}: {e}")
            
            logger.info(f"Cleaned up expired transfer {tid}")


async def send_to_websocket(transfer: Transfer, message: dict):
    """Send message to websocket, queue if not connected yet"""
    if transfer.websocket:
        try:
            await transfer.websocket.send_json(message)
        except Exception as e:
            logger.debug(f"WebSocket send failed: {e}")
    else:
        # Queue message for when websocket connects
        transfer._pending_messages.append(message)


async def parse_croc_output(line: str, transfer: Transfer):
    """Parse croc output for progress information"""
    progress_match = re.search(r'(\d+(?:\.\d+)?)\s*%', line)
    speed_match = re.search(r'(\d+(?:\.\d+)?\s*[KMG]?B/s)', line)
    
    if progress_match:
        transfer.progress = float(progress_match.group(1))
    if speed_match:
        transfer.speed = speed_match.group(1)
    
    code_match = re.search(r'Code is:\s*(\S+)', line)
    if code_match:
        transfer.code = code_match.group(1)
    
    if "file(s) sent" in line.lower() or "file(s) received" in line.lower():
        transfer.status = "completed"
        transfer.progress = 100.0
    
    # Detect croc help/error message (indicates --classic flag is needed or other config issue)
    # This specific phrase only appears in the help text, not in normal transfer output
    # Normal send output says "CROC_SECRET=<actual-code>" but help says "CROC_SECRET=****"
    if "to receive with croc you either need" in line.lower() or "croc_secret=****" in line.lower():
        transfer.error = "croc configuration error - received help message instead of transfer"
        transfer.status = "failed"
    
    # Capture error messages (but not lines that just contain instructions with "other")
    if ("error" in line.lower() or "failed" in line.lower() or 
        "permission denied" in line.lower() or "cannot write" in line.lower() or
        "no such file" in line.lower() or "access denied" in line.lower()) and "on the other" not in line.lower():
        transfer.error = line


async def run_croc_send(transfer: Transfer, file_paths: list[Path]):
    """Run croc send command"""
    transfer.status = "running"
    transfer_dir = file_paths[0].parent
    
    # Build command with options
    cmd = [CROC_EXECUTABLE, "send"]
    if transfer.options:
        cmd.extend(transfer.options.to_args())
    cmd.extend([str(p) for p in file_paths])
    
    logger.info(f"Transfer {transfer.id}: Running command: {cmd}")
    logger.info(f"Transfer {transfer.id}: Working directory: {transfer_dir}")
    
    # Verify croc executable exists
    croc_path = Path(CROC_EXECUTABLE)
    if not croc_path.exists() and not shutil.which(CROC_EXECUTABLE):
        error_msg = f"croc executable not found: {CROC_EXECUTABLE}"
        logger.error(f"Transfer {transfer.id}: {error_msg}")
        transfer.status = "failed"
        transfer.error = error_msg
        await send_to_websocket(transfer, {
            "type": "complete",
            "id": transfer.id,
            "status": transfer.status,
            "error": transfer.error
        })
        return
    
    # Verify all files exist
    for fp in file_paths:
        if not fp.exists():
            error_msg = f"File not found: {fp}"
            logger.error(f"Transfer {transfer.id}: {error_msg}")
            transfer.status = "failed"
            transfer.error = error_msg
            await send_to_websocket(transfer, {
                "type": "complete",
                "id": transfer.id,
                "status": transfer.status,
                "error": transfer.error
            })
            return
    
    try:
        # Set environment to enable classic mode without prompting
        env = os.environ.copy()
        env["CROC_CLASSIC"] = "true"
        
        transfer.process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.DEVNULL,  # Prevent blocking on stdin
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(transfer_dir),
            env=env
        )
        
        # Read output in chunks to handle \r progress updates (croc uses \r for progress)
        buffer = ""
        while True:
            try:
                chunk = await transfer.process.stdout.read(1024)
                if not chunk:
                    break
                buffer += chunk.decode(errors='replace')
                
                # Split on both \r and \n to capture progress updates
                while '\r' in buffer or '\n' in buffer:
                    # Find the earliest separator
                    r_pos = buffer.find('\r')
                    n_pos = buffer.find('\n')
                    
                    if r_pos == -1:
                        pos = n_pos
                    elif n_pos == -1:
                        pos = r_pos
                    else:
                        pos = min(r_pos, n_pos)
                    
                    line = buffer[:pos].strip()
                    buffer = buffer[pos + 1:]
                    
                    if line:
                        await parse_croc_output(line, transfer)
                        await send_to_websocket(transfer, {
                            "type": "progress",
                            "id": transfer.id,
                            "code": transfer.code,
                            "status": transfer.status,
                            "progress": transfer.progress,
                            "speed": transfer.speed,
                            "raw": line
                        })
            except Exception as e:
                logger.warning(f"Transfer {transfer.id}: Error reading output: {e}")
                break
        
        # Process any remaining buffer content
        if buffer.strip():
            await parse_croc_output(buffer.strip(), transfer)
        
        await transfer.process.wait()
        
        # Only mark as completed if not already marked as failed by error detection
        if transfer.status != "failed":
            if transfer.process.returncode == 0:
                transfer.status = "completed"
            else:
                transfer.status = "failed"
                if not transfer.error:
                    transfer.error = f"croc exited with code {transfer.process.returncode}"
    
    except FileNotFoundError as e:
        # This specifically catches [WinError 2] - file not found for executable
        logger.error(f"Transfer {transfer.id} failed - executable not found: {e}")
        transfer.status = "failed"
        transfer.error = f"croc executable not found: {CROC_EXECUTABLE}. Please ensure croc is installed and accessible."
    except Exception as e:
        logger.error(f"Transfer {transfer.id} failed: {e}")
        transfer.status = "failed"
        transfer.error = str(e)
    
    await send_to_websocket(transfer, {
        "type": "complete",
        "id": transfer.id,
        "status": transfer.status,
        "error": transfer.error
    })
    
    # Schedule cleanup
    await cleanup_old_transfers()


async def run_croc_receive(transfer: Transfer, code: str, download_dir: Optional[Path] = None):
    """Run croc receive command"""
    logger.info(f"Transfer {transfer.id}: Starting receive for code {code}")
    
    transfer.status = "running"
    transfer.code = code
    receive_dir = None
    
    try:
        # Use custom download directory if provided and valid, otherwise use default
        if download_dir and download_dir.exists() and download_dir.is_dir():
            receive_dir = download_dir
            logger.info(f"Transfer {transfer.id}: Using custom download directory: {receive_dir}")
        else:
            receive_dir = UPLOAD_DIR / f"receive_{transfer.id}"
            logger.info(f"Transfer {transfer.id}: Creating receive directory: {receive_dir}")
            receive_dir.mkdir(exist_ok=True)
            if sys.platform != "win32":
                receive_dir.chmod(0o700)
        
        # Store receive_dir in transfer for later use by file listing endpoints
        transfer.receive_dir = receive_dir
        
        # Record existing files BEFORE transfer (to detect only NEW files after)
        existing_files = set()
        try:
            existing_files = {f.name for f in receive_dir.iterdir() if f.is_file()}
            logger.debug(f"Transfer {transfer.id}: {len(existing_files)} existing files in directory")
        except Exception as e:
            logger.warning(f"Transfer {transfer.id}: Could not list existing files: {e}")
        
        # Use CROC_SECRET environment variable to pass the code securely
        # This avoids the --classic flag which is just a toggle setting, not a transfer mode
        env = os.environ.copy()
        env["CROC_SECRET"] = code
        
        # Build command: just croc --yes (code is passed via CROC_SECRET env var)
        cmd = [CROC_EXECUTABLE, "--yes"]
        if transfer.options:
            if transfer.options.curve and transfer.options.curve in VALID_CURVES:
                cmd.extend(["--curve", transfer.options.curve])
            if transfer.options.hash and transfer.options.hash in VALID_HASHES:
                cmd.extend(["--hash", transfer.options.hash])
            if transfer.options.relay and re.match(r'^[a-zA-Z0-9\.\-]+:\d+$', transfer.options.relay):
                cmd.extend(["--relay", transfer.options.relay])
            if transfer.options.no_local:
                cmd.append("--no-local")
        
        logger.info(f"Transfer {transfer.id}: Running command: {cmd} (with CROC_SECRET)")
        logger.info(f"Transfer {transfer.id}: Working directory: {receive_dir}")
        
        transfer.process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(receive_dir),
            env=env
        )
        
        # Read output in chunks to handle \r progress updates (croc uses \r for progress)
        buffer = ""
        while True:
            try:
                chunk = await transfer.process.stdout.read(1024)
                if not chunk:
                    break
                buffer += chunk.decode(errors='replace')
                
                # Split on both \r and \n to capture progress updates
                while '\r' in buffer or '\n' in buffer:
                    # Find the earliest separator
                    r_pos = buffer.find('\r')
                    n_pos = buffer.find('\n')
                    
                    if r_pos == -1:
                        pos = n_pos
                    elif n_pos == -1:
                        pos = r_pos
                    else:
                        pos = min(r_pos, n_pos)
                    
                    line = buffer[:pos].strip()
                    buffer = buffer[pos + 1:]
                    
                    if line:
                        logger.debug(f"Transfer {transfer.id}: croc output: {line}")
                        await parse_croc_output(line, transfer)
                        await send_to_websocket(transfer, {
                            "type": "progress",
                            "id": transfer.id,
                            "status": transfer.status,
                            "progress": transfer.progress,
                            "speed": transfer.speed,
                            "raw": line
                        })
            except Exception as e:
                logger.warning(f"Transfer {transfer.id}: Error reading output: {e}")
                break
        
        # Process any remaining buffer content
        if buffer.strip():
            await parse_croc_output(buffer.strip(), transfer)
        
        await transfer.process.wait()
        logger.info(f"Transfer {transfer.id}: croc process exited with code {transfer.process.returncode}")
        
        # Only mark as completed if not already marked as failed by error detection
        if transfer.status != "failed":
            if transfer.process.returncode == 0:
                # Find files that are NEW (didn't exist before transfer)
                current_files = {f.name for f in receive_dir.iterdir() if f.is_file()}
                new_files = list(current_files - existing_files)
                
                if new_files:
                    transfer.status = "completed"
                    transfer.files = new_files
                    logger.info(f"Transfer {transfer.id}: Completed, received {len(new_files)} files: {new_files}")
                else:
                    transfer.status = "failed"
                    transfer.error = "No files received - transfer may have failed silently"
                    logger.warning(f"Transfer {transfer.id}: {transfer.error}")
            else:
                transfer.status = "failed"
                if not transfer.error:
                    transfer.error = f"croc exited with code {transfer.process.returncode}"
                logger.error(f"Transfer {transfer.id}: {transfer.error}")
    
    except PermissionError as e:
        error_msg = f"Permission denied: {e}"
        logger.error(f"Transfer {transfer.id}: {error_msg}")
        transfer.status = "failed"
        transfer.error = error_msg
    
    except Exception as e:
        logger.error(f"Transfer {transfer.id} failed with exception: {e}", exc_info=True)
        transfer.status = "failed"
        transfer.error = str(e)
    
    await send_to_websocket(transfer, {
        "type": "complete",
        "id": transfer.id,
        "status": transfer.status,
        "files": transfer.files,
        "error": transfer.error
    })
    
    await cleanup_old_transfers()


@app.get("/", response_class=HTMLResponse)
async def index():
    html_content = (BASE_DIR / "static" / "index.html").read_text(encoding='utf-8')
    # NOTE: CSP uses 'unsafe-inline' for scripts/styles as a trade-off for single-file architecture.
    # This is intentional - the app has no user-generated content that could exploit inline scripts.
    return Response(
        content=html_content,
        media_type="text/html",
        headers={
            "Content-Security-Policy": (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                "font-src 'self' https://fonts.gstatic.com; "
                "connect-src 'self' ws: wss:; "
                "img-src 'self' data:; "
            ),
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "SAMEORIGIN",
        }
    )


@app.post("/api/send")
async def upload_files(request: Request):
    """Upload files and start a croc send - handles large files via streaming"""
    transfer_id = secrets.token_urlsafe(8)
    transfer_dir = UPLOAD_DIR / transfer_id
    transfer_dir.mkdir(exist_ok=True)
    if sys.platform != "win32":
        transfer_dir.chmod(0o700)
    
    file_paths: List[Path] = []
    file_names: List[str] = []
    total_size = 0
    croc_options = None
    
    try:
        content_type = request.headers.get("content-type", "")
        
        if "multipart/form-data" not in content_type:
            raise HTTPException(400, "Content-Type must be multipart/form-data")
        
        # Extract boundary from content-type
        boundary = None
        for part in content_type.split(";"):
            part = part.strip()
            if part.startswith("boundary="):
                boundary = part[9:].strip('"')
                break
        
        if not boundary:
            raise HTTPException(400, "Missing boundary in Content-Type")
        
        # Stream and parse multipart data manually for unlimited file size support
        boundary_bytes = f"--{boundary}".encode()
        end_boundary = f"--{boundary}--".encode()
        
        buffer = b""
        current_file = None
        current_field_name = None
        current_filename = None
        options_data = b""
        in_headers = True
        headers = {}
        
        async for chunk in request.stream():
            buffer += chunk
            
            while True:
                if in_headers:
                    # Look for end of headers (double CRLF)
                    header_end = buffer.find(b"\r\n\r\n")
                    if header_end == -1:
                        break
                    
                    # Parse headers
                    header_section = buffer[:header_end].decode(errors='replace')
                    buffer = buffer[header_end + 4:]
                    
                    # Check for boundary
                    if header_section.startswith(f"--{boundary}"):
                        # New part starting
                        # Close previous file if any
                        if current_file:
                            current_file.close()
                            file_paths.append(current_file_path)
                            file_names.append(current_file_path.name)
                            current_file = None
                        
                        if header_section.strip() == f"--{boundary}--":
                            # End of multipart
                            break
                        
                        # Parse headers for this part
                        headers = {}
                        current_field_name = None
                        current_filename = None
                        
                        for line in header_section.split("\r\n")[1:]:  # Skip boundary line
                            if ":" in line:
                                key, value = line.split(":", 1)
                                headers[key.strip().lower()] = value.strip()
                        
                        # Parse content-disposition
                        cd = headers.get("content-disposition", "")
                        for item in cd.split(";"):
                            item = item.strip()
                            if item.startswith("name="):
                                current_field_name = item[5:].strip('"')
                            elif item.startswith("filename="):
                                current_filename = item[9:].strip('"')
                        
                        # If it's a file, open it for writing
                        if current_filename:
                            safe_name = secure_filename(current_filename)
                            current_file_path = get_unique_filepath(transfer_dir, safe_name)
                            current_file = open(current_file_path, "wb")
                        
                        in_headers = False
                    else:
                        # Looking for a boundary
                        boundary_pos = buffer.find(boundary_bytes)
                        if boundary_pos == -1:
                            # No boundary yet, process data up to buffer end minus boundary length
                            safe_len = max(0, len(buffer) - len(boundary_bytes) - 4)
                            if safe_len > 0:
                                data = buffer[:safe_len]
                                buffer = buffer[safe_len:]
                                
                                if current_file:
                                    current_file.write(data)
                                    total_size += len(data)
                                elif current_field_name == "options":
                                    options_data += data
                            break
                else:
                    # Looking for next boundary
                    boundary_pos = buffer.find(boundary_bytes)
                    if boundary_pos == -1:
                        # No boundary found, write all but potential partial boundary
                        safe_len = max(0, len(buffer) - len(boundary_bytes) - 4)
                        if safe_len > 0:
                            data = buffer[:safe_len]
                            buffer = buffer[safe_len:]
                            
                            if current_file:
                                current_file.write(data)
                                total_size += len(data)
                            elif current_field_name == "options":
                                options_data += data
                        break
                    else:
                        # Found boundary - write data before it (minus CRLF)
                        data_end = boundary_pos
                        if boundary_pos >= 2 and buffer[boundary_pos-2:boundary_pos] == b"\r\n":
                            data_end = boundary_pos - 2
                        
                        if data_end > 0:
                            data = buffer[:data_end]
                            if current_file:
                                current_file.write(data)
                                total_size += len(data)
                            elif current_field_name == "options":
                                options_data += data
                        
                        buffer = buffer[boundary_pos:]
                        in_headers = True
                        
                        # Close current file
                        if current_file:
                            current_file.close()
                            file_paths.append(current_file_path)
                            file_names.append(current_file_path.name)
                            current_file = None
        
        # Handle remaining buffer
        if current_file:
            # Write remaining data (remove trailing boundary if present)
            data = buffer
            for ending in [end_boundary, boundary_bytes, b"\r\n"]:
                if data.endswith(ending):
                    data = data[:-len(ending)]
            if data.endswith(b"\r\n"):
                data = data[:-2]
            if data:
                current_file.write(data)
                total_size += len(data)
            current_file.close()
            file_paths.append(current_file_path)
            file_names.append(current_file_path.name)
        
        # Parse options
        if options_data:
            try:
                croc_options = CrocOptions.model_validate_json(options_data.decode())
            except Exception as e:
                logger.warning(f"Invalid options JSON: {e}")
        
        if not file_paths:
            raise HTTPException(400, "No files uploaded")
            
    except HTTPException:
        if transfer_dir.exists():
            shutil.rmtree(transfer_dir, ignore_errors=True)
        raise
    except Exception as e:
        if transfer_dir.exists():
            shutil.rmtree(transfer_dir, ignore_errors=True)
        error_msg = str(e)
        logger.error(f"Upload failed: {error_msg}", exc_info=True)
        raise HTTPException(400, f"Upload failed: {error_msg}")
    
    transfer = Transfer(
        id=transfer_id,
        type="send",
        files=file_names,
        total_size=total_size,
        options=croc_options
    )
    
    async with transfers_lock:
        transfers[transfer_id] = transfer
    
    asyncio.create_task(run_croc_send(transfer, file_paths))
    
    return {"id": transfer_id, "files": file_names}


class SendPathRequest(BaseModel):
    """Request body for send-by-path endpoint"""
    paths: List[str]
    options: Optional[CrocOptions] = None


@app.post("/api/send-path")
async def send_by_path(request: SendPathRequest):
    """Send files/folders by local path - no upload, no copying, zero disk usage.
    
    This passes paths directly to croc, which reads files from their original location.
    Only works when the paths are accessible from the server.
    """
    if not request.paths:
        raise HTTPException(400, "No paths provided")
    
    # Validate all paths exist and collect info
    file_paths: List[Path] = []
    file_names: List[str] = []
    total_size = 0
    
    for path_str in request.paths:
        path = Path(path_str).resolve()
        
        # Security: block obvious system paths
        path_lower = str(path).lower()
        if sys.platform == "win32":
            blocked = ["c:\\windows", "c:\\program files"]
        else:
            blocked = ["/bin", "/sbin", "/usr", "/etc", "/boot", "/lib", "/root"]
        
        is_blocked = any(path_lower == b or path_lower.startswith(b + os.sep) for b in blocked)
        if str(path) == "/" or (sys.platform == "win32" and len(str(path)) <= 3 and str(path).endswith(":\\")):
            is_blocked = True
        
        if is_blocked:
            raise HTTPException(400, f"Cannot send system directory: {path}")
        
        if not path.exists():
            raise HTTPException(404, f"Path not found: {path}")
        
        # Calculate size
        if path.is_file():
            total_size += path.stat().st_size
            file_names.append(path.name)
        elif path.is_dir():
            # Count total size of directory
            for f in path.rglob("*"):
                if f.is_file():
                    try:
                        total_size += f.stat().st_size
                    except (PermissionError, OSError):
                        pass
            file_names.append(f"{path.name}/ (folder)")
        else:
            raise HTTPException(400, f"Path is not a file or directory: {path}")
        
        file_paths.append(path)
    
    transfer_id = secrets.token_urlsafe(8)
    
    transfer = Transfer(
        id=transfer_id,
        type="send",
        files=file_names,
        total_size=total_size,
        options=request.options
    )
    
    async with transfers_lock:
        transfers[transfer_id] = transfer
    
    # Pass paths directly to croc - no copying!
    asyncio.create_task(run_croc_send(transfer, file_paths))
    
    return {
        "id": transfer_id, 
        "files": file_names, 
        "total_size": total_size,
        "note": "Sending directly from disk - no upload needed"
    }


@app.get("/api/download-dirs")
async def get_download_directories():
    """Get suggested download directories for the current system"""
    directories = []
    
    if sys.platform == "win32":
        # Windows directories
        user_profile = os.environ.get("USERPROFILE", "")
        if user_profile:
            possible_dirs = [
                (Path(user_profile) / "Downloads", "Downloads"),
                (Path(user_profile) / "Documents", "Documents"),
                (Path(user_profile) / "Desktop", "Desktop"),
                (Path(user_profile), "Home"),
            ]
        else:
            possible_dirs = []
            logger.warning("USERPROFILE environment variable not set")
    else:
        # Unix/Linux/macOS directories
        try:
            home = Path.home()
            logger.debug(f"Detected home directory: {home}")
            possible_dirs = [
                (home / "Downloads", "Downloads"),
                (home / "Documents", "Documents"),
                (home / "Desktop", "Desktop"),
                (home, "Home"),
                (Path("/tmp"), "Temporary"),
            ]
        except Exception as e:
            logger.warning(f"Could not determine home directory: {e}")
            possible_dirs = [(Path("/tmp"), "Temporary")]
    
    for path, name in possible_dirs:
        if path.exists() and path.is_dir():
            try:
                # Check if we can write to this directory
                test_file = path / f".croc_test_{secrets.token_hex(4)}"
                test_file.touch()
                test_file.unlink()
                directories.append({
                    "path": str(path),
                    "name": name,
                    "writable": True
                })
                logger.debug(f"Directory {path} is writable")
            except Exception as e:
                directories.append({
                    "path": str(path),
                    "name": name,
                    "writable": False
                })
                logger.debug(f"Directory {path} is not writable: {e}")
    
    # Also include the default app directory
    default_dir = UPLOAD_DIR / "downloads"
    default_dir.mkdir(exist_ok=True)
    directories.insert(0, {
        "path": str(default_dir),
        "name": "App Default",
        "writable": True
    })
    
    return {"directories": directories}


@app.post("/api/validate-path")
async def validate_download_path(path: str = Query(...)):
    """Validate if a path is usable as a download directory"""
    try:
        resolved = Path(path).resolve()
        
        if not resolved.exists():
            return {"valid": False, "error": "Path does not exist"}
        
        if not resolved.is_dir():
            return {"valid": False, "error": "Path is not a directory"}
        
        # Security check: ensure it's not a system directory
        if sys.platform == "win32":
            system_dirs = ["C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)"]
        else:
            system_dirs = ["/bin", "/sbin", "/usr", "/etc", "/var", "/root", "/boot", "/lib", "/lib64"]
        
        path_str = str(resolved)
        is_system_dir = (
            path_str == "/" or  # Root directory
            any(path_str == sd or path_str.startswith(sd + "/") or path_str.startswith(sd + "\\") 
                for sd in system_dirs)
        )
        if is_system_dir:
            return {"valid": False, "error": "Cannot use system directory"}
        
        # Check if writable
        try:
            test_file = resolved / f".croc_test_{secrets.token_hex(4)}"
            test_file.touch()
            test_file.unlink()
        except Exception:
            return {"valid": False, "error": "Directory is not writable"}
        
        return {"valid": True, "path": str(resolved)}
    except Exception as e:
        return {"valid": False, "error": str(e)}


@app.post("/api/receive")
async def receive_files(
    code: str = Query(..., min_length=5, max_length=100),
    curve: Optional[str] = Query(None),
    hash: Optional[str] = Query(None, alias="hash_algo"),  # 'hash' is reserved
    relay: Optional[str] = Query(None),
    no_local: bool = Query(False),
    download_dir: Optional[str] = Query(None)
):
    """Start a croc receive"""
    # Validate croc code format (more permissive)
    if not CROC_CODE_PATTERN.match(code):
        raise HTTPException(400, "Invalid croc code format. Expected format: word-word-word (e.g., 1234-crane-river)")
    
    # Validate and resolve download directory if provided
    resolved_download_dir = None
    if download_dir:
        try:
            download_path = Path(download_dir).resolve()
            if download_path.exists() and download_path.is_dir():
                # Security check: ensure it's not a system directory
                # Note: We check for exact match OR path prefix (with /)
                if sys.platform == "win32":
                    system_dirs = ["C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)"]
                else:
                    system_dirs = ["/bin", "/sbin", "/usr", "/etc", "/var", "/root", "/boot", "/lib", "/lib64"]
                
                path_str = str(download_path)
                is_system_dir = (
                    path_str == "/" or  # Root directory
                    any(path_str == sd or path_str.startswith(sd + "/") or path_str.startswith(sd + "\\") 
                        for sd in system_dirs)
                )
                if not is_system_dir:
                    resolved_download_dir = download_path
                    logger.info(f"Using custom download directory: {resolved_download_dir}")
                else:
                    logger.warning(f"Rejected system directory as download path: {download_path}")
            else:
                logger.warning(f"Download directory does not exist or is not a directory: {download_path}")
        except Exception as e:
            logger.warning(f"Invalid download directory path: {e}")
    
    # Build options
    croc_options = CrocOptions(
        curve=curve,
        hash=hash,
        relay=relay,
        no_local=no_local
    )
    
    transfer_id = secrets.token_urlsafe(8)
    
    transfer = Transfer(
        id=transfer_id,
        type="receive",
        code=code,
        options=croc_options
    )
    
    async with transfers_lock:
        transfers[transfer_id] = transfer
    
    # Create task with error handling
    task = asyncio.create_task(run_croc_receive(transfer, code, resolved_download_dir))
    
    def handle_task_exception(t):
        if t.cancelled():
            logger.warning(f"Transfer {transfer_id} task was cancelled")
        elif t.exception():
            logger.error(f"Transfer {transfer_id} task failed with exception: {t.exception()}", exc_info=t.exception())
    
    task.add_done_callback(handle_task_exception)
    
    return {"id": transfer_id, "download_dir": str(resolved_download_dir) if resolved_download_dir else None}


@app.get("/api/transfer/{transfer_id}")
async def get_transfer(transfer_id: str):
    """Get transfer status"""
    async with transfers_lock:
        if transfer_id not in transfers:
            raise HTTPException(404, "Transfer not found")
        t = transfers[transfer_id]
    
    return {
        "id": t.id,
        "type": t.type,
        "code": t.code,
        "files": t.files,
        "status": t.status,
        "progress": t.progress,
        "speed": t.speed,
        "error": t.error
    }


@app.delete("/api/transfer/{transfer_id}")
async def cancel_transfer(transfer_id: str):
    """Cancel a transfer"""
    async with transfers_lock:
        if transfer_id not in transfers:
            raise HTTPException(404, "Transfer not found")
        t = transfers[transfer_id]
        # Copy process reference while holding lock
        process = t.process
        t.status = "cancelled"
    
    # Terminate process outside lock to avoid blocking other operations
    if process and process.returncode is None:
        process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=5)
        except asyncio.TimeoutError:
            process.kill()
    
    return {"status": "cancelled"}


@app.get("/api/transfer/{transfer_id}/files")
async def list_received_files(transfer_id: str):
    """List files available for download from a completed receive transfer"""
    async with transfers_lock:
        if transfer_id not in transfers:
            raise HTTPException(404, "Transfer not found")
        t = transfers[transfer_id]
    
    if t.type != "receive":
        raise HTTPException(400, "Only receive transfers have downloadable files")
    
    if t.status != "completed":
        raise HTTPException(400, "Transfer not completed")
    
    # Use stored receive_dir or fallback to default
    receive_dir = t.receive_dir if t.receive_dir else UPLOAD_DIR / f"receive_{transfer_id}"
    if not receive_dir.exists():
        raise HTTPException(404, "Files no longer available")
    
    # Only return files that were actually transferred (stored in t.files)
    files = []
    transferred_files = set(t.files) if t.files else set()
    
    for f in receive_dir.iterdir():
        if f.is_file() and f.name in transferred_files:
            files.append({
                "name": f.name,
                "size": f.stat().st_size
            })
    
    return {"files": files, "directory": str(receive_dir)}


@app.get("/api/transfer/{transfer_id}/download/{filename}")
async def download_received_file(transfer_id: str, filename: str):
    """Download a specific file from a completed receive transfer"""
    async with transfers_lock:
        if transfer_id not in transfers:
            raise HTTPException(404, "Transfer not found")
        t = transfers[transfer_id]
    
    if t.type != "receive":
        raise HTTPException(400, "Only receive transfers have downloadable files")
    
    if t.status != "completed":
        raise HTTPException(400, "Transfer not completed")
    
    # Sanitize filename to prevent path traversal
    safe_name = secure_filename(filename)
    # Use stored receive_dir or fallback to default
    receive_dir = t.receive_dir if t.receive_dir else UPLOAD_DIR / f"receive_{transfer_id}"
    file_path = receive_dir / safe_name
    
    # Ensure the file is within the receive directory
    try:
        file_path.resolve().relative_to(receive_dir.resolve())
    except ValueError:
        raise HTTPException(403, "Access denied")
    
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(404, "File not found")
    
    return FileResponse(
        file_path,
        filename=safe_name,
        media_type="application/octet-stream"
    )


@app.post("/api/transfer/{transfer_id}/open-in-explorer/{filename}")
async def open_in_explorer(transfer_id: str, filename: str):
    """Open the file's containing folder in the system file explorer"""
    async with transfers_lock:
        if transfer_id not in transfers:
            raise HTTPException(404, "Transfer not found")
        t = transfers[transfer_id]
    
    if t.type != "receive":
        raise HTTPException(400, "Only receive transfers have downloadable files")
    
    if t.status != "completed":
        raise HTTPException(400, "Transfer not completed")
    
    # Sanitize filename to prevent path traversal
    safe_name = secure_filename(filename)
    receive_dir = t.receive_dir if t.receive_dir else UPLOAD_DIR / f"receive_{transfer_id}"
    file_path = receive_dir / safe_name
    
    # Ensure the file is within the receive directory
    try:
        file_path.resolve().relative_to(receive_dir.resolve())
    except ValueError:
        raise HTTPException(403, "Access denied")
    
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(404, "File not found")
    
    try:
        if sys.platform == "win32":
            # Windows: open explorer and select the file
            subprocess.Popen(['explorer', '/select,', str(file_path)])
        elif sys.platform == "darwin":
            # macOS: reveal in Finder
            subprocess.Popen(['open', '-R', str(file_path)])
        else:
            # Linux: try to open the containing folder
            # Different file managers have different commands
            folder = str(receive_dir)
            
            # Try dbus method first (works with most modern file managers)
            try:
                subprocess.Popen([
                    'dbus-send', '--print-reply', '--dest=org.freedesktop.FileManager1',
                    '/org/freedesktop/FileManager1', 'org.freedesktop.FileManager1.ShowItems',
                    f'array:string:file://{file_path}', 'string:""'
                ])
            except Exception:
                # Fallback to xdg-open on the folder
                subprocess.Popen(['xdg-open', folder])
        
        return {"status": "opened", "path": str(file_path)}
    except Exception as e:
        logger.error(f"Failed to open file explorer: {e}")
        raise HTTPException(500, f"Failed to open file explorer: {e}")


@app.websocket("/ws/{transfer_id}")
async def websocket_endpoint(websocket: WebSocket, transfer_id: str):
    """WebSocket for real-time transfer updates"""
    await websocket.accept()
    
    async with transfers_lock:
        transfer = transfers.get(transfer_id)
        if transfer:
            transfer.websocket = websocket
            pending = list(transfer._pending_messages)
            transfer._pending_messages.clear()
        else:
            pending = []
    
    # Send queued messages outside lock
    for msg in pending:
        try:
            await websocket.send_json(msg)
        except Exception as e:
            logger.debug(f"Failed to send queued message: {e}")
    
    try:
        while True:
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        async with transfers_lock:
            if transfer_id in transfers:
                transfers[transfer_id].websocket = None


async def graceful_shutdown():
    """Gracefully terminate all active transfers on shutdown"""
    logger.info("Initiating graceful shutdown...")
    shutdown_event.set()
    
    async with transfers_lock:
        active_transfers = list(transfers.values())
    
    for transfer in active_transfers:
        if transfer.process and transfer.process.returncode is None:
            logger.info(f"Terminating transfer {transfer.id}")
            transfer.process.terminate()
            try:
                await asyncio.wait_for(transfer.process.wait(), timeout=5)
            except asyncio.TimeoutError:
                transfer.process.kill()
            
            # Notify connected clients
            if transfer.websocket:
                try:
                    await transfer.websocket.send_json({
                        "type": "complete",
                        "id": transfer.id,
                        "status": "cancelled",
                        "error": "Server shutting down"
                    })
                except Exception:
                    pass
    
    logger.info("Graceful shutdown complete")


# Mount static files
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT)
